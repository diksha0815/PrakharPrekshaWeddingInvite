# Wedding Invite Website

## Edit details
- Change names, events, venue and phone numbers in `index.html`.
- Replace images inside `assets/` with your own images.
- Optional music: add `music.mp3` to `assets/`, then uncomment the audio source line in `index.html`.

## Publish on GitHub Pages
1. Go to github.com and sign in.
2. Click **New repository**.
3. Repository name: `wedding-invite`.
4. Keep it **Public**.
5. Click **Create repository**.
6. Click **uploading an existing file**.
7. Upload all files from this folder: `index.html`, `style.css`, `script.js`, `README.md`, and the `assets` folder.
8. Click **Commit changes**.
9. Go to **Settings → Pages**.
10. Under **Build and deployment**, choose **Deploy from a branch**.
11. Branch: `main`, folder: `/root`.
12. Click **Save**.
13. Wait 2–5 minutes. Your link will be shown there.

Your link will look like:
`https://YOURUSERNAME.github.io/wedding-invite/`
