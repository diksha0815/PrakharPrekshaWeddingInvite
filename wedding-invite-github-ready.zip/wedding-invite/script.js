const openScreen = document.getElementById('open-screen');
const invite = document.getElementById('invite');
const openBtn = document.getElementById('openInvite');
const music = document.getElementById('music');
const musicBtn = document.getElementById('musicBtn');

openBtn.addEventListener('click', () => {
  openScreen.style.opacity = '0';
  openScreen.style.pointerEvents = 'none';
  invite.classList.remove('hidden');
  setTimeout(() => openScreen.style.display = 'none', 600);
  music.play().catch(() => {});
});

musicBtn.addEventListener('click', () => {
  if (music.paused) { music.play().catch(() => {}); musicBtn.textContent='♪'; }
  else { music.pause(); musicBtn.textContent='×'; }
});

const weddingDate = new Date('2026-07-19T13:45:00+05:30').getTime();
function tick(){
  const diff = Math.max(0, weddingDate - Date.now());
  const d = Math.floor(diff/(1000*60*60*24));
  const h = Math.floor((diff/(1000*60*60))%24);
  const m = Math.floor((diff/(1000*60))%60);
  const s = Math.floor((diff/1000)%60);
  document.getElementById('days').textContent = String(d).padStart(2,'0');
  document.getElementById('hours').textContent = String(h).padStart(2,'0');
  document.getElementById('mins').textContent = String(m).padStart(2,'0');
  document.getElementById('secs').textContent = String(s).padStart(2,'0');
}
tick(); setInterval(tick,1000);
